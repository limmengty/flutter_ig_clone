class RealText {
  List<String> likes = [
    '100.0k',
    '200.0k',
    '212.8k',
    '188.4k',
    '726.1k',
    '123.9k',
    '897.0k',
    '728.9k'
  ];
  List<String> comments = [
    '199',
    '335',
    '188',
    '92',
    '121',
    '88',
    '211',
    '902'
  ];
  List<String> shares = ['89', '788', '112', '909', '121', '726', '198', '282'];
  List<String> descriptions = [
    'This is the thing that make them special 💜NO HATE TO OTHER IDOLS 💜#subscribeformore💜',
    'Learn CSS Flexbox Flex-wrap in 24 Seconds',
    'Best moment of Argus Part 5, MLBB.',
    'How to Make Text Made of Halftone Lines in Illustrator',
    'Everyone is perfect in their own way............... #blackpink #trending #kpop #shorts #fyp',
    'Why do boys eat so Fast?🧒🏻🍚 #shorts #couple #relationship',
    'Is Bro Hacking In Geometry Dash #shorts',
    '',
  ];
}
