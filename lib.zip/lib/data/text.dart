class Texts{
    final List<String> profileName = [
    '',
    "thesorng",
    "taylorswift",
    "Ksenia",
    "eunwo.o_c",
    "m_kayoung",
    "bernardokath",
    "biqqboyy",
    "hi_high_hiy",
  ];
  final List<String> captions = [
    "The red rose is known as the flower of love. The red rose symbolizes deep emotions and desires. Red roses are traditionally given to symbolize love, but aren't the only ones to earn this title. Other types of love flowers include peonies, sunflowers, or tulips, which symbolize happiness, prosperity and romance.",
    "Stress",
    "Awwww",
    "What's wrong??",
    "What the !!!",
    "Natural.",
    "Wooow",
    "Who are you?",
  ];
  List<String> storyCaptions = ["Beach", "Tokyo", "Breakfast", "View", "Paris"];
  List<String> userProfileName = [
    "Your Stories",
  ];
}