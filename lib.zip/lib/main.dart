import 'package:flutter/material.dart';
// import 'package:flutter_clone_ig/insta_app/insta_app.dart';
import 'package:flutter_clone_ig/insta_app/login_screen.dart';
// import 'package:flutter_clone_ig/pages/newpost.dart';
void main() {
  // runApp(Post());
  runApp(Login());
}

